<?php
$con = mysqli_connect('localhost','root');
if($con){
    echo "connection Successful";
}
else{
    echo "no connection";
}
mysqli_select_db($con,'personaluserdata');
?>