<?php
$con = mysqli_connect('localhost','root');
if($con){
    echo "connection Successful";
}
else{
    echo "no connection";
}
mysqli_select_db($con,'personaluserdata');

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $enquiry = $_POST['enquiry'];
    $phone = $_POST['phone'];
    $query = $con->prepare("INSERT INTO `userinfodata`( `Name`, `Email`, `Enquiry`, `Phone`) VALUES (?,?,?,?)");
    $query->bind_param('ssss',$name,$email,$enquiry,$phone);
    $query->execute();
    if($query->affected_rows>0){
        echo "success";

    }
    else{
        echo "failed";
    }
}

?>