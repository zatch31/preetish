import re
def name():
    
    fname = input("Enter your First Name: ")
    mname = input("Enter your Middle Name: ")
    lname = input("Enter your Last Name: ")
    x="Name of the student is "+lname+","+ fname+" "+ mname
    y=x.title()
    print(y.strip())    

def enroll():
    unid= input("Enter your unique ID: ") 
    unid.isalnum()
    pattern="(\d{4}\w{2}\d{4})"
    match= re.match(pattern,unid)
    if match:
        print("The ID is correct.")
    else:
        print("Please Enter a valid ID please Re enter.")

def marks():
    n=int(input('Enter number of subjects:'))
    sum=0
    for i in range(1,n+1):
        sub=input('Enter subject name:')
        m=int(input('Enter marks:'))
        if(m>100):
            assert 'Invalid marks'
        elif(m>=80):
            print('Grade in',sub.title(),'is A')
        elif(m>=60 and m<80 ):
            print('Grade in',sub.title(),'is B')
        elif(m>=40 and m<60):
            print('Grade in',sub.title(),'is C')
        elif(m<40):
            print('Grade in',sub.title(),'is D(Fail)')

def main():
    name()
    enroll()
    marks()
main()