Web technology- using php, bootstrap, html,css, ajax, js, jquery.,

data base - using mysql.

Install a xampp server to load database copy the project file into htdocs folder, open a browser localhost/hospital in browser 